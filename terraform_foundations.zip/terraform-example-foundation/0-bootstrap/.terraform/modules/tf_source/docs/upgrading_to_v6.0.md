# Upgrading to v6.0

## Terraform Validator is migrated to gcloud terraform-tools component

terraform-validator is migrated to `gcloud beta terraform vet`[https://cloud.google.com/docs/terraform/policy-validation].
