Cache directory.
